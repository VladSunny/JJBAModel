# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


import os
import json
import traceback
import sys
from collections import defaultdict
import textwrap

from .connection import *
# from .prefs import *
from .enums import *
from .os_iface import *
from .version import UvpmVersionInfo
from .blend import get_scene_props

import bpy
import bpy_types
import bmesh



def get_engine_path():
    return get_prefs().engine_path


def get_engine_execpath():
    engine_basename = 'uvpm'
    return os.path.join(get_engine_path(), os_exec_dirname(), engine_basename + os_exec_extension())


def process_file_path(file_path):
    return os.path.realpath(file_path)


def in_debug_mode(debug_lvl = 1):
    return bpy.app.debug_value >= debug_lvl or bpy.app.debug


def split_by_chars(str, cnt):
    str_split = str.split()

    array = []
    curr_str = ''
    curr_cnt = 0

    for word in str_split:
        curr_str += ' ' + word
        curr_cnt += len(word)

        if curr_cnt > cnt:
            array.append((curr_str))
            curr_str = ''
            curr_cnt = 0

    if curr_str != '':
        array.append((curr_str))

    return array
        

def print_backtrace(ex):
    _, _, trback = sys.exc_info()
    traceback.print_tb(trback)
    trbackDump = traceback.extract_tb(trback)
    filename, line, func, msg = trbackDump[-1]

    print('Line: {} Message: {}'.format(line, msg))
    print(str(ex))


def print_debug(debug_str):
    print('[UVPACKMASTER_DEBUG]: ' + debug_str)

def print_log(log_str):
    print('[UVPACKMASTER_LOG]: ' + log_str)

def print_error(error_str):
    print('[UVPACKMASTER_ERROR]: ' + error_str)

def print_warning(warning_str):
    print('[UVPACKMASTER_WARNING]: ' + warning_str)

def log_separator():
    return '-'*80

def rgb_to_rgba(rgb_color):

    return (rgb_color[0], rgb_color[1], rgb_color[2], 1.0)


def redraw_ui(context):

    for area in context.screen.areas:
        if area is not None:
            area.tag_redraw()


def get_active_image_size(context):

    img = None
    for area in context.screen.areas:
        if area.type == 'IMAGE_EDITOR':
            img = area.spaces.active.image

    if img is None:
        raise RuntimeError("Non-Square Packing: active texture required for the operation")

    if img.size[0] == 0 or img.size[1] == 0:
        raise RuntimeError("Non-Square Packing: active texture has invalid dimensions")

    return (img.size[0], img.size[1])


def get_active_image_ratio(context):

    img_size = get_active_image_size(context)

    return float(img_size[0]) / float(img_size[1])


def get_prop_type(collection, prop_id):
    return collection.bl_rna.properties[prop_id].type


def get_prop_name(collection, prop_id):
    return collection.bl_rna.properties[prop_id].name


def parse_json_file(json_file_path):
    with open(json_file_path) as f:
        try:
            data = json.load(f)
        except Exception as e:
            if in_debug_mode():
                print_backtrace(e)
            data = None
    return data


def unique_min_num(num_list, num_from=0):
    if not num_list:
        return num_from
    counter = num_from
    while True:
        counter += 1
        if counter in num_list:
            continue
        return counter


def unique_name(value, collection, instance=None):
    if collection.find(value) > -1:
        name_parts = value.rsplit(".", 1)
        base_name = name_parts[0]
        name_num_list = []
        found = 0
        same_found = 0
        for element in collection:
            if element == instance:
                continue

            if element.name.startswith(base_name):
                if element.name == value:
                    same_found += 1
                element_name_parts = element.name.rsplit(".", 1)
                if element_name_parts[0] != base_name:
                    continue
                found += 1
                if len(element_name_parts) < 2 or not element_name_parts[1].isnumeric():
                    continue
                name_num_list.append(int(element_name_parts[1]))

        if found > 0 and same_found > 0:
            return "{}.{:03d}".format(base_name, unique_min_num(name_num_list or [0]))
    return value


def snake_to_camel_case(snake_case_str):
    words = snake_case_str.split('_')
    camel_case_str = ''.join(word.capitalize() for word in words)
    return camel_case_str


def swap_attr(obj1, obj2, attr_name):
    tmp = getattr(obj1, attr_name)
    setattr(obj1, attr_name, getattr(obj2, attr_name))
    setattr(obj2, attr_name, tmp)


def is_builtin_class_instance(obj):
    return obj.__class__.__module__ == '__builtin__'


class ShadowedPropertyGroupMeta(bpy_types.RNAMetaPropGroup):
    def __new__(cls, name, bases, dct):
        shadow_cls = type(name, bases + (__ShadowPropertyGroup__,), dct)
        new_cls = super().__new__(cls, name, bases + (bpy.types.PropertyGroup,), dct)
        shadow_cls._real_cls = new_cls
        new_cls._shadow_cls = shadow_cls
        return new_cls


class __ShadowPropertyGroup__:
    def __getattr__(self, item):
        return getattr(self._real_cls, item)

    def cast_setattr(self, key, value):
        _types_func = {'BOOLEAN': bool, 'INT': int, 'FLOAT': float, 'STRING': str, 'ENUM': str}

        def _cast_value(_value, _type):
            _cast_func = _types_func.get(_type)
            if _cast_func is None:
                return _value
            return _cast_func(_value)

        prop_struct = self.bl_rna.properties.get(key, None)
        if prop_struct is not None and prop_struct.type in _types_func:
            prop_type = prop_struct.type
            is_array = getattr(prop_struct, 'is_array', False)
            if is_array:
                value = type(value)(_cast_value(v, prop_type) for v in value)
            else:
                value = _cast_value(value, prop_type)
        super().__setattr__(key, value)

    def property_unset(self, prop_name):
        prop_struct = self.bl_rna.properties[prop_name]
        is_array = getattr(prop_struct, 'is_array', False)
        if is_array and hasattr(prop_struct, 'default_array'):
            setattr(self, prop_name, prop_struct.default_array)
        elif hasattr(prop_struct, 'default'):
            setattr(self, prop_name, prop_struct.default)


class ShadowedPropertyGroup:
    def __new__(cls, *args, **kwargs):
        if hasattr(cls, "_shadow_cls"):
            return cls._shadow_cls(*args, **kwargs)
        return super().__new__(cls)


class ShadowedCollectionProperty:

    def __init__(self, elem_type):

        self.elem_type = elem_type
        self.collection = []

    def add(self):

        self.collection.append(self.elem_type())
        return self.collection[-1]

    def clear(self):

        self.collection.clear()

    def remove(self, idx):

        del self.collection[idx]

    def __len__(self):

        return len(self.collection)

    def __getitem__(self, idx):

            return self.collection[idx]

    def __iter__(self):

        return iter(self.collection)
        

class PropertyWrapper:

    def __init__(self, obj, prop_id):
        self.obj = obj
        self.prop_id = prop_id

    def get_value(self):
        return getattr(self.obj, self.prop_id)
    
    def draw(self, layout, text=None):
        kwargs = {}
        if text is not None:
            kwargs['text'] = text

        layout.prop(self.obj, self.prop_id, **kwargs)

    def get_name(self):
        return self.obj.rna_type.properties[self.prop_id].name if hasattr(self.obj, self.prop_id) else ''

    def to_script_param(self):
        from .prefs_scripted_utils import ScriptParams
        return ScriptParams.to_param(self.get_value())

        
class CollectionPropertyDictWrapper:

    def __init__(self, collection, key_name, value_name):
        self.collection = collection
        self.key_name = key_name
        self.value_name = value_name
        self.dict = { getattr(elem, self.key_name): getattr(elem, self.value_name) for elem in self.collection }

    def get(self, key):

        return self.dict.get(key)

    def __getitem__(self, key):

        value = self.get(key)
        if value is not None:
            return value
            
        new_elem = self.collection.add()
        setattr(new_elem, self.key_name, key)
        new_value = getattr(new_elem, self.value_name)
        self.dict[key] = new_value
        return new_value
    

class PanelUtilsMixin:

    @classmethod
    def _draw_help_operator(cls, layout, help_url_suffix):
        from .help import UVPM3_OT_Help
        help_op = layout.operator(UVPM3_OT_Help.bl_idname, icon=UVPM3_OT_Help.ICON, text='')
        help_op.url_suffix = help_url_suffix

    @classmethod
    def _draw_help_popover(cls, layout, help_panel_t):
        help_row = layout.row()
        help_row.emboss = 'NONE'
        help_row.popover(panel=help_panel_t.__name__, icon=help_panel_t.ICON, text="")

    @classmethod
    def _draw_multiline_label(cls, layout, text, width):
        chars = int(width / 6)
        wrapper = textwrap.TextWrapper(width=chars)
        text_lines = wrapper.wrap(text=text)
        for text_line in text_lines:
            layout.label(text=text_line)

    @staticmethod
    def draw_engine_status(prefs, layout):
        if not prefs.engine_initialized:
            box = layout.box()
            box.alert = True
            prefs.draw_engine_status(box)

    @staticmethod
    def draw_prop_name_up(obj, prop_id, layout):
        col = layout.column(align=True)
        col.label(text=PropertyWrapper(obj, prop_id).get_name() + ':')
        col.prop(obj, prop_id, text='')

    @classmethod
    def draw_enum_in_box(cls, obj, prop_id, layout, help_url_suffix=None, expand=False, not_supported_msg=None, prop_name=None):

        supported = not_supported_msg is None
        prop_kwargs = { 'expand' : expand }
        if not expand:
            prop_kwargs['text'] = ''

        box = layout.box()
        col = box.column(align=True)

        if prop_name is None:
            prop_name = PropertyWrapper(obj, prop_id).get_name()

        if prop_name:
            label_row = col.row(align=True)
            label_row.label(text=prop_name + ':')
            label_row.enabled = supported
            
        row = col.row(align=True)
        prop_row = row.row(align=True)
        prop_row.prop(obj, prop_id, **prop_kwargs)
        prop_row.enabled=supported

        if help_url_suffix:
            cls._draw_help_operator(row, help_url_suffix)

        if not supported:
            from .help import UVPM3_OT_WarningPopup
            UVPM3_OT_WarningPopup.draw_operator(row, text=not_supported_msg)

        return col

    @classmethod
    def get_active_mode(cls, context):
        return None

    def init_draw(self, context):

        self.prefs = get_prefs()
        self.scene_props = get_scene_props(context)
        self.scripted_props = self.scene_props.scripted_props
        self.context = context

        if not hasattr(self, 'multi_panel'):
            self.multi_panel = False

        self.props_with_help = not self.multi_panel
        
        self.active_mode = self.get_active_mode(context)